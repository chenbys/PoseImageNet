# SampleTrack.json User Guide

`SampleTrack.json` maps the image IDs in `PoseImageNet.json` to their relative
paths in the ImageNet or UniKPT source datasets.

## 1. File Structure

The file is a JSON mapping dictionary:

```json
{
  "1": "ImageNet\\images_train\\n01682714\\n01682714_1007.JPEG",
  "117241": "300w\\images\\afw\\90800092_2.jpg"
}
```

- Keys: the `images[].id` values in `PoseImageNet.json`. JSON object keys are strings.
- Values: the relative path of that image in the ImageNet or UniKPT source dataset.

ImageNet path format:

```text
ImageNet\images_train\<WordNet class directory>\<source image file name>
```

UniKPT path format:

```text
<sub-dataset>\<sub-dataset internal path>\<source image file name>
```

For example:

```text
Image ID 1 in PoseImageNet.json
    -> ImageNet\images_train\n01682714\n01682714_1007.JPEG

Image ID 117241 in PoseImageNet.json
    -> 300w\images\afw\90800092_2.jpg
```

## 2. Current Scope

The current file is strictly synchronized with the `images[]` of
`poseimagenet.json` and contains only the source path mappings of the images
that are currently kept:

| Item | Count |
| --- | ---: |
| Total image ID mappings | 69,788 |
| ImageNet image ID mappings | 60,007 |
| UniKPT image ID mappings | 9,781 |
| WordNet class directories involved | 555 |
| Mappings whose source file was not found | 0 |


The canonical image of this model is `n03544143_1114.JPEG`, with
`image_id = 164244`, corresponding to `canonical_sample_id = 30530`. Query
example:

```json
{
  "164244": "ImageNet\\images_train\\n03544143\\n03544143_1114.JPEG"
}
```

`D:\image` is the current directory of the curated images and annotations; the
mapping values still use the ImageNet source-relative path format above and are
not rewritten as `D:\image` paths.

## 3. Look Up by Image ID

```python
import json

with open("SampleTrack.json", "r", encoding="utf-8") as file:
    sample_track = json.load(file)

image_id = 1
source_path = sample_track[str(image_id)]
print(source_path)
```

Output:

```text
ImageNet\images_train\n01682714\n01682714_1007.JPEG
```

The integer image ID must be converted to a string before lookup, because the
keys of the JSON mapping dictionary are strings.

## 4. Get the Full Source File Path

Assume the local directory layout is:

```text
G:\ch
└── images_train
    └── n01682714
        └── n01682714_1007.JPEG
```

The actual source directory for ImageNet is `G:\ch\images_train`, and the
actual source directory for UniKPT is `G:\ch\dataset\unikpt\images`. Files can
be located as follows:

```python
from pathlib import Path, PureWindowsPath


def source_file(sample_track, image_id):
    relative_path = PureWindowsPath(sample_track[str(image_id)])
    if relative_path.parts[0] == "ImageNet":
        return Path(r"G:\ch").joinpath(*relative_path.parts[1:])
    return Path(r"G:\ch\dataset\unikpt\images").joinpath(
        *relative_path.parts
    )


print(source_file(sample_track, image_id))
```

which gives:

```text
G:\ch\images_train\n01682714\n01682714_1007.JPEG
```

Looking up the UniKPT example `image_id = 117241` gives:

```text
G:\ch\dataset\unikpt\images\300w\images\afw\90800092_2.jpg
```

## 5. Use Together with PoseImageNet.json

To find the ImageNet or UniKPT source file of an image in `PoseImageNet.json`:

```python
import json
from pathlib import Path, PureWindowsPath

with open("PoseImageNet.json", "r", encoding="utf-8") as file:
    pose_data = json.load(file)

with open("SampleTrack.json", "r", encoding="utf-8") as file:
    sample_track = json.load(file)

images_by_id = {image["id"]: image for image in pose_data["images"]}

image_id = 1
image = images_by_id[image_id]
full_source_path = source_file(sample_track, image_id)

print("Current data path:", image["file_name"])
print("Source path:", full_source_path)
```

## 6. Iterate Over All Mappings

```python
for image_id_text, relative_path_text in sample_track.items():
    image_id = int(image_id_text)
    full_path = source_file(sample_track, image_id)

    if not full_path.is_file():
        print("Source file missing:", image_id, full_path)
```

The current `SampleTrack.json` has been checked entry by entry: every record
resolves to an existing image in the corresponding ImageNet or UniKPT source
directory.
